Discord chat logger
This can be added to my other discord bot, if you want to do this but dont know how dm me and ill send you the code. My tag: Hecker_6807
Saves all chats in your server and puts them in a txt file. here is the format;
@<user> hi
--------------------------------------------------------------
@<user> wanna play?
--------------------------------------------------------------
and so on.
Install pip if you havent by typing this in your cmd:
python get-pip.py
And intall discord and logging:
pip install discord.py
pip install logging
Requires Python, install python here: https://www.python.org/ftp/python/3.12.4/python-3.12.4-amd64.exe
PASTE LINK IN BROWSER TO GET RIGHT VERSION


search up on youtube on how to make a bot and enable administrator. Turn developer mode on, on discrod google it if you dont know how to and right click the server and copy the id and copy the channel id the same way.
Get a bot at: https://discord.com/developers/applications       <-------- # paste in browser

!Have fun and sorry for any spelling mistakes!


__  __    _    ____  _____   ______   __  __  __  ___ _____ _____        _____ ____  _ ____  _____ 
|  \/  |  / \  |  _ \| ____| | __ ) \ / / |  \/  |/ _ \_   _/ _ \ \      / /_ _/ ___|/ |___ \|___ / 
| |\/| | / _ \ | | | |  _|   |  _ \\ V /  | |\/| | | | || || | | \ \ /\ / / | |\___ \| | __) | |_ \ 
| |  | |/ ___ \| |_| | |___  | |_) || |   | |  | | |_| || || |_| |\ V  V /  | | ___) | |/ __/ ___) |
|_|  |_/_/   \_\____/|_____| |____/ |_|   |_|  |_|\___/ |_| \___/  \_/\_/  |___|____/|_|_____|____/ 

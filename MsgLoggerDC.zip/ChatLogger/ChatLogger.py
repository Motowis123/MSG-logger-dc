import discord
from discord.ext import commands
import logging

logging.basicConfig(level=logging.INFO)

# Replace with your Discord bot token found in the developer portal; link: https://discord.com/developers/applications
DISCORD_API_TOKEN = 'discord_bot_token_here'

# Path to the log file only change user, you may change the folder if you know what your doing!
LOG_FILE = 'C:/Users/user/Desktop/ChatLogger/log.txt'

intents = discord.Intents.default()
intents.messages = True  
intents.message_content = True  

bot = commands.Bot(command_prefix="+", intents=intents)

@bot.event
async def on_ready():
    print(f'Bot is ready and logged in as {bot.user}')

@bot.event
async def on_message(message):
    try:
        if message.author == bot.user:
            return
        
        log_entry = f'@{message.author} {message.content}\n'
        with open(LOG_FILE, 'a', encoding='utf-8') as file:
            file.write(log_entry)
            file.write('-' * 72 + '\n')
            
    except Exception as e:
        logging.error(f"Error logging message: {e}")

    await bot.process_commands(message)

bot.run(DISCORD_API_TOKEN)




#__  __    _    ____  _____   ______   __  __  __  ___ _____ _____        _____ ____  _ ____  _____ 
#|  \/  |  / \  |  _ \| ____| | __ ) \ / / |  \/  |/ _ \_   _/ _ \ \      / /_ _/ ___|/ |___ \|___ / 
#| |\/| | / _ \ | | | |  _|   |  _ \\ V /  | |\/| | | | || || | | \ \ /\ / / | |\___ \| | __) | |_ \ 
#| |  | |/ ___ \| |_| | |___  | |_) || |   | |  | | |_| || || |_| |\ V  V /  | | ___) | |/ __/ ___) |
#|_|  |_/_/   \_\____/|_____| |____/ |_|   |_|  |_|\___/ |_| \___/  \_/\_/  |___|____/|_|_____|____/ 